#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "f32c::f32c" for configuration "Release"
set_property(TARGET f32c::f32c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(f32c::f32c PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libf32c.so"
  IMPORTED_SONAME_RELEASE "libf32c.so"
  )

list(APPEND _cmake_import_check_targets f32c::f32c )
list(APPEND _cmake_import_check_files_for_f32c::f32c "${_IMPORT_PREFIX}/lib/libf32c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
