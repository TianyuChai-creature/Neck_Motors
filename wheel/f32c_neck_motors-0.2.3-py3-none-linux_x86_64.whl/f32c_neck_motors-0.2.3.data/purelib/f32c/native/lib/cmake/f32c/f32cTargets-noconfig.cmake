#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "f32c::f32c" for configuration ""
set_property(TARGET f32c::f32c APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(f32c::f32c PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libf32c.so"
  IMPORTED_SONAME_NOCONFIG "libf32c.so"
  )

list(APPEND _cmake_import_check_targets f32c::f32c )
list(APPEND _cmake_import_check_files_for_f32c::f32c "${_IMPORT_PREFIX}/lib/libf32c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
